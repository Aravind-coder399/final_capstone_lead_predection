<img width="1415" height="798" alt="image" src="https://github.com/user-attachments/assets/20762686-5f12-48a6-b843-bdd2145dfcdd" />
