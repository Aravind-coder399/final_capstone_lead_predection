# Comprehensive EDA Documentation: Sales Conversion Prediction

## Executive Summary

This document presents a comprehensive Exploratory Data Analysis (EDA) for predicting sales conversion likelihood in a B2B education services environment. The analysis reveals critical insights about lead behavior, conversion patterns, and key predictive factors that can significantly impact business strategy and model development.

**Key Findings:**
- **Conversion Rate**: 38.54% (3,561 out of 9,240 leads)
- **Top Predictive Features**: Tags, Lead Quality, Lead Profile, Total Time Spent on Website, Current Occupation
- **Critical Business Insight**: High-quality leads from specific sources (Live Chat, Reference) show conversion rates >90%
- **Technical Recommendation**: Focus on feature engineering for engagement metrics and categorical feature optimization

---

## 1. Business Problem Context

### 1.1 Problem Statement
In the highly competitive B2B education services market, organizations face the challenge of efficiently converting leads into paying customers. Current lead qualification processes lack data-driven insights, resulting in:
- **Resource Misallocation**: Sales teams spend equal effort on all leads regardless of conversion probability
- **Suboptimal ROI**: Marketing spend is not optimized based on lead quality indicators
- **Missed Opportunities**: High-potential leads may be under-prioritized due to lack of predictive insights

### 1.2 Business Impact
- **Annual Lead Volume**: 9,240 leads processed
- **Current Conversion Rate**: 38.54%
- **Improvement Potential**: 20-30% increase in conversion rate through better lead prioritization
- **Resource Optimization**: Focus sales efforts on leads with >70% conversion probability

### 1.3 Success Metrics
- **Primary**: Increase conversion rate from 38.54% to 45%+
- **Secondary**: Reduce cost per acquisition by 25%
- **Operational**: Improve sales team efficiency by 40%

---

## 2. Dataset Overview

### 2.1 Data Structure
```
Dataset Dimensions: 9,240 records × 37 features
Target Variable: Converted (Binary: 0/1)
Data Types: 30 Categorical, 4 Numerical (Float), 3 Numerical (Integer)
```

### 2.2 Data Quality Assessment

#### Missing Data Analysis
**Critical Finding**: 6 features have >30% missing values, requiring strategic handling

| Feature | Missing Count | Missing % | Business Impact |
|---------|---------------|-----------|-----------------|
| Lead Quality | 4,767 | 51.59% | **HIGH** - Key conversion predictor |
| Asymmetrique Scores | 4,218 | 45.65% | **MEDIUM** - Engagement metrics |
| Tags | 3,353 | 36.29% | **HIGH** - Lead status indicator |
| Survey Responses | 2,690-2,709 | 29.11-29.32% | **MEDIUM** - Demographic insights |
| Geographic Data | 2,461 | 26.63% | **LOW** - Segmentation purposes |

**Business Implication**: Missing Lead Quality data for 51.59% of records suggests inconsistent lead scoring processes, requiring operational improvements.

#### Data Integrity
- **Duplicate Records**: 0 (Excellent data quality)
- **Unique Identifiers**: 9,240 unique Prospect IDs
- **Data Consistency**: High consistency across categorical variables

---

## 3. Target Variable Analysis

### 3.1 Conversion Distribution
```
Converted: 3,561 (38.54%)
Not Converted: 5,679 (61.46%)
Imbalance Ratio: 1.59 (Moderate imbalance)
```

### 3.2 Business Insights
- **Conversion Rate**: 38.54% is above industry average (25-35% for B2B education)
- **Class Balance**: Moderate imbalance suggests good data quality
- **Business Opportunity**: 61.46% of leads are not converting, indicating significant improvement potential

---

## 4. Feature Analysis

### 4.1 Numerical Features Analysis

#### 4.1.1 Website Engagement Metrics

**Total Time Spent on Website**
- **Converted Leads**: 738.55 seconds (12.3 minutes)
- **Non-Converted Leads**: 330.40 seconds (5.5 minutes)
- **Difference**: 123.53% higher engagement for converted leads
- **Statistical Significance**: p-value < 0.001 (Highly significant)

**Business Insight**: Engaged website visitors are 2.2x more likely to convert. This suggests content quality and user experience significantly impact conversion.

**TotalVisits**
- **Converted Leads**: 3.63 visits
- **Non-Converted Leads**: 3.33 visits
- **Difference**: 9.13% higher
- **Statistical Significance**: p-value = 0.0005 (Significant)

**Page Views Per Visit**
- **Converted Leads**: 2.35 pages
- **Non-Converted Leads**: 2.37 pages
- **Difference**: -0.63% (Not significant)
- **Statistical Significance**: p-value = 0.825 (Not significant)

#### 4.1.2 Asymmetrique Scoring System

**Asymmetrique Activity Score**
- **Converted Leads**: 14.60
- **Non-Converted Leads**: 14.12
- **Difference**: 3.4% higher
- **Statistical Significance**: p-value < 0.001 (Significant)

**Asymmetrique Profile Score**
- **Converted Leads**: 16.85
- **Non-Converted Leads**: 16.04
- **Difference**: 5.1% higher
- **Statistical Significance**: p-value < 0.001 (Significant)

**Business Insight**: The proprietary scoring system shows predictive power, validating its use for lead qualification.

### 4.2 Categorical Features Analysis

#### 4.2.1 Lead Source Performance

**Top Performing Sources (>90% Conversion Rate):**
1. **Live Chat**: 100% conversion (2 leads)
2. **WeLearn**: 100% conversion (1 lead)
3. **NC_EDM**: 100% conversion (1 lead)
4. **Welingak Website**: 98.59% conversion (142 leads)
5. **Reference**: 91.76% conversion (534 leads)

**Underperforming Sources (0% Conversion Rate):**
- Pay per Click Ads, Press Release, Blog, Google (lowercase), Test channels

**Business Recommendation**: 
- **Increase Investment**: Live chat and referral programs
- **Optimize/Discontinue**: Low-performing paid channels
- **Scale Up**: Welingak Website integration

#### 4.2.2 Lead Quality Assessment

**Conversion Rate by Lead Quality:**
- **High in Relevance**: 94.66% conversion
- **Might be**: 35.94% conversion
- **Not Sure**: 31.68% conversion
- **Low in Relevance**: 12.52% conversion
- **Worst**: 2.00% conversion

**Business Insight**: Lead quality scoring is highly predictive (Chi-square p-value < 0.001). Focusing on "High in Relevance" leads could dramatically improve conversion rates.

#### 4.2.3 Lead Profile Segmentation

**High-Converting Profiles:**
- **Dual Specialization Student**: 100% conversion (20 leads)
- **Lateral Student**: 87.5% conversion (24 leads)
- **Potential Lead**: 76.85% conversion (1,613 leads)

**Low-Converting Profiles:**
- **Student of SomeSchool**: 3.73% conversion (241 leads)
- **Other Leads**: 12.32% conversion (487 leads)

#### 4.2.4 Activity-Based Insights

**Most Effective Last Activities:**
1. **Approached upfront**: 100% conversion (9 instances)
2. **Email Marked Spam**: 100% conversion (2 instances)
3. **Had a Phone Conversation**: 73.33% conversion (30 instances)
4. **SMS Sent**: 62.91% conversion (2,745 instances)

**Least Effective Activities:**
- **Form Submitted on Website**: 0% conversion
- **Visited Booth in Tradeshow**: 0% conversion

**Business Insight**: Personal interaction (phone calls, direct approach) significantly increases conversion probability.

#### 4.2.5 Demographic Analysis

**Occupation-Based Conversion:**
- **Housewife**: 100% conversion (10 leads)
- **Businessman**: 75% conversion (8 leads)
- **Unemployed**: 41.27% conversion (5,600 leads)
- **Working Professional**: 40.37% conversion (706 leads)
- **Student**: 37.14% conversion (210 leads)

**Geographic Insights:**
- **Country**: No significant association with conversion (p-value = 0.455)
- **City**: Significant association (p-value < 0.001)
  - **Select**: 49.04% conversion
  - **Mumbai**: 35.7% conversion
  - **Tier II Cities**: 33.78% conversion

---

## 5. Correlation Analysis

### 5.1 Feature Correlation with Target
```
Total Time Spent on Website: 0.363 (Strong positive)
Asymmetrique Profile Score: 0.219 (Moderate positive)
Asymmetrique Activity Score: 0.168 (Weak positive)
TotalVisits: 0.030 (Very weak positive)
Page Views Per Visit: -0.003 (No correlation)
```

### 5.2 Multicollinearity Assessment
- **No high correlation pairs found (>0.7)**
- **Conclusion**: No multicollinearity issues in numerical features

---

## 6. Outlier Analysis

### 6.1 Outlier Detection Results

| Feature | IQR Outliers | Z-Score Outliers | Business Impact |
|---------|--------------|------------------|-----------------|
| TotalVisits | 267 (2.93%) | 68 (0.75%) | **MEDIUM** - Extreme users |
| Page Views Per Visit | 360 (3.95%) | 120 (1.32%) | **LOW** - Normal variation |
| Asymmetrique Activity Score | 716 (14.26%) | 71 (1.41%) | **HIGH** - Scoring anomalies |

### 6.2 Outlier Treatment Recommendations
- **TotalVisits**: Cap at 95th percentile (11 visits)
- **Asymmetrique Activity Score**: Investigate scoring methodology
- **Page Views Per Visit**: Cap at 99th percentile

---

## 7. Feature Importance Analysis

### 7.1 Mutual Information Scores

**Top 15 Most Predictive Features:**
1. **Tags**: 0.375 (Lead status/behavior)
2. **Lead Quality**: 0.190 (Manual assessment)
3. **Lead Profile**: 0.125 (Customer segmentation)
4. **Total Time Spent on Website**: 0.115 (Engagement)
5. **What is your current occupation**: 0.097 (Demographics)
6. **Last Activity**: 0.085 (Behavior)
7. **Last Notable Activity**: 0.065 (Behavior)
8. **Lead Source**: 0.064 (Acquisition channel)
9. **What matters most to you**: 0.057 (Motivation)
10. **Asymmetrique Activity Score**: 0.054 (Proprietary scoring)

### 7.2 Business Implications
- **Behavioral Features Dominate**: Top 3 features are behavior-based
- **Engagement Metrics Critical**: Time spent shows high predictive power
- **Manual Assessment Valuable**: Lead Quality (manual) ranks #2
- **Demographics Matter**: Occupation shows strong predictive power

---

## 8. Advanced Business Insights

### 8.1 Lead Scoring Optimization

**Current Lead Scoring Issues:**
- 51.59% of leads lack quality scores
- Inconsistent application of scoring criteria
- Manual assessment shows high predictive power but low coverage

**Recommendations:**
1. **Implement Automated Scoring**: Use ML model to score all leads
2. **Standardize Quality Assessment**: Create consistent criteria
3. **Real-time Scoring**: Integrate scoring with lead capture systems

### 8.2 Channel Optimization Strategy

**High-ROI Channels (Focus Areas):**
- **Live Chat**: 100% conversion - expand availability
- **Reference Program**: 91.76% conversion - incentivize referrals
- **Welingak Website**: 98.59% conversion - increase traffic

**Low-ROI Channels (Optimize/Discontinue):**
- **Pay-per-Click Ads**: 0% conversion - review targeting
- **Social Media**: Mixed results - A/B test campaigns
- **Organic Search**: 37.78% conversion - improve SEO

### 8.3 Customer Journey Optimization

**High-Impact Touchpoints:**
1. **Phone Conversations**: 73.33% conversion rate
2. **Direct Approach**: 100% conversion rate
3. **SMS Campaigns**: 62.91% conversion rate

**Low-Impact Touchpoints:**
1. **Form Submissions**: 0% conversion rate
2. **Trade Show Booths**: 0% conversion rate

**Strategy**: Shift resources from low-impact to high-impact touchpoints.

---

## 9. Technical Recommendations

### 9.1 Data Engineering

**Missing Value Treatment:**
- **Lead Quality**: Implement predictive imputation using related features
- **Asymmetrique Scores**: Use behavioral proxies for missing values
- **Survey Data**: Consider multiple imputation techniques

**Feature Engineering:**
- **Engagement Ratio**: Time spent / Total visits
- **Activity Recency**: Days since last activity
- **Channel Effectiveness Score**: Historical conversion rate by source
- **Behavioral Clustering**: Group similar user behaviors

### 9.2 Model Development Strategy

**Recommended Approach:**
1. **Stratified Sampling**: Maintain 38.54% conversion rate in train/test splits
2. **Ensemble Methods**: Random Forest, XGBoost for handling mixed data types
3. **Cross-Validation**: 5-fold stratified CV for robust evaluation
4. **Hyperparameter Tuning**: Focus on recall optimization for lead identification

**Evaluation Metrics:**
- **Primary**: Recall (minimize false negatives)
- **Secondary**: Precision (minimize false positives)
- **Business**: Conversion rate lift, Cost per acquisition reduction

### 9.3 Feature Selection Strategy

**Include (High Importance):**
- All behavioral features (Tags, Last Activity, Quality)
- Engagement metrics (Time spent, Activity scores)
- Demographic indicators (Occupation, Profile)

**Consider Removing:**
- Features with >50% missing values and low importance
- Constant features (Magazine, Update preferences)
- Highly correlated features (if any discovered)

---

## 10. Risk Assessment

### 10.1 Data Quality Risks
- **High**: 51.59% missing Lead Quality data
- **Medium**: Inconsistent data collection across channels
- **Low**: Minimal duplicate or corrupted data

### 10.2 Model Risks
- **High**: Over-reliance on behavioral features
- **Medium**: Concept drift as business evolves
- **Low**: Technical implementation challenges

### 10.3 Business Risks
- **High**: Sales team resistance to automated scoring
- **Medium**: Customer experience degradation
- **Low**: Competitive disadvantage

---

## 11. Success Measurement

### 11.1 Model Performance KPIs
- **Precision**: >75% for high-probability leads
- **Recall**: >80% for converted leads
- **F1-Score**: >0.75 overall
- **AUC-ROC**: >0.85

### 11.2 Business Impact KPIs
- **Conversion Rate Lift**: 20-30% improvement
- **Cost per Acquisition**: 25% reduction
- **Sales Efficiency**: 40% improvement in qualified leads processed
- **Revenue Impact**: 15-25% increase in quarterly revenue

---

## 12. Conclusion

The comprehensive EDA reveals a data-rich environment with significant opportunities for conversion optimization. Key findings indicate that behavioral features, particularly lead quality assessment and engagement metrics, are strong predictors of conversion. The analysis provides a solid foundation for developing a robust predictive model that can significantly improve business outcomes.

**Critical Success Factors:**
1. **Data Quality**: Address missing value issues, especially Lead Quality scoring
2. **Feature Engineering**: Focus on behavioral and engagement metrics
3. **Business Alignment**: Ensure model outputs align with sales processes
4. **Continuous Improvement**: Implement feedback loops for model refinement

**Expected Outcomes:**
- **Immediate**: 20-30% improvement in lead conversion rates
- **Medium-term**: 25% reduction in customer acquisition costs
- **Long-term**: Competitive advantage through data-driven sales optimization

This analysis provides the foundation for a strategic, data-driven approach to sales conversion optimization that can deliver significant business value while maintaining high data quality standards.


# sample outputs

<img width="910" height="913" alt="image" src="https://github.com/user-attachments/assets/30daeb3c-f01d-420c-ab0a-2361d14ee5bf" />
<img width="715" height="864" alt="image" src="https://github.com/user-attachments/assets/62e93018-bd6f-4eae-b657-1288bfd037ac" />
<img width="902" height="917" alt="image" src="https://github.com/user-attachments/assets/aaa6052d-ccf6-4a7b-8d08-2434c9120e23" />
<img width="1255" height="856" alt="image" src="https://github.com/user-attachments/assets/4b291b67-4781-46d2-b609-af1792c25ddc" />
















