
# mlflow output
<img width="1918" height="988" alt="Screenshot 2025-07-18 134722" src="https://github.com/user-attachments/assets/561d387d-c006-4071-a590-97b5ae576957" />
<img width="1916" height="927" alt="Screenshot 2025-07-18 134804" src="https://github.com/user-attachments/assets/a07fd316-3ef5-4b2a-9401-9f17c4f826bb" />
