# s3 to redshift
<img width="1918" height="857" alt="image" src="https://github.com/user-attachments/assets/373f2642-f53c-45e1-a532-af415cc68661" />
