# s3 buckets
<img width="1908" height="861" alt="image" src="https://github.com/user-attachments/assets/4bb4745e-309f-40ef-95d2-faa1820c7fc9" />
