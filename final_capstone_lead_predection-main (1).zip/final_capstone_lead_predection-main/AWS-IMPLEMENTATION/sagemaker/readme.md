
# sagemaker jupyter notebook
<img width="1739" height="847" alt="image" src="https://github.com/user-attachments/assets/aa81b89f-8d42-40fa-8879-6b5bda1b4c47" />

# sagemaker modal registory
<img width="1737" height="846" alt="image" src="https://github.com/user-attachments/assets/d3efac2a-368c-4f9c-863d-f226404f880a" />

# sagemaker model registory multiple version 
<img width="1123" height="577" alt="image" src="https://github.com/user-attachments/assets/d3292d88-55ad-41bf-97c3-b51ccfc6793c" />


# sagemaker pipeline
<img width="1738" height="838" alt="image" src="https://github.com/user-attachments/assets/2548890a-e77d-4978-9c07-43b73cc74584" />


# sagemaker endpoint
<img width="1753" height="824" alt="image" src="https://github.com/user-attachments/assets/ce9f4657-dde5-4290-a194-ae87e427077d" />

