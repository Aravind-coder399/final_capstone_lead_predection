# s3 dag script to run airflow
<img width="1918" height="1044" alt="image" src="https://github.com/user-attachments/assets/19715737-d67a-434c-9aa0-9f8d69e992f6" />

# s3 code file for task
<img width="1919" height="898" alt="image" src="https://github.com/user-attachments/assets/8337d6e1-f15e-40ed-b959-4eb9103148c3" />

# s3 for data drift detection
<img width="1914" height="958" alt="image" src="https://github.com/user-attachments/assets/8a606f72-9b9a-40b5-a852-53ba1e303cb8" />

# Airflow dag
<img width="1919" height="945" alt="image" src="https://github.com/user-attachments/assets/6ac191c2-3f9c-4c4f-9ef4-8cf10903b143" />

# Xcom for retrain logic
<img width="1913" height="1032" alt="image" src="https://github.com/user-attachments/assets/d7e5eda7-39db-4c53-816e-a7dbac54dad6" />
