# loding data to redshift
<img width="1600" height="840" alt="image" src="https://github.com/user-attachments/assets/d4574a23-7363-402b-8c2e-628745ea2ca1" />
