
# run output screenshort
<img width="1911" height="994" alt="Screenshot 2025-07-18 134651" src="https://github.com/user-attachments/assets/d94dbf7e-b7d6-4252-9c82-7116b340930c" />
<img width="1915" height="982" alt="Screenshot 2025-07-17 225923" src="https://github.com/user-attachments/assets/f47c2cbb-606e-4565-bd7c-c2b9c1c378b1" />
<img width="1913" height="932" alt="Screenshot 2025-07-18 134917" src="https://github.com/user-attachments/assets/77ddb70e-b1c6-41ea-8f2f-97a6781b29be" />
<img width="1919" height="992" alt="Screenshot 2025-07-18 134935" src="https://github.com/user-attachments/assets/81659589-34ea-40ac-8a3f-a5a8f806414c" />
<img width="1914" height="989" alt="Screenshot 2025-07-18 134950" src="https://github.com/user-attachments/assets/0542bab1-bd46-4be8-8a96-3626f1ef0fd3" />





