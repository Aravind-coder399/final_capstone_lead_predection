
# output screenshort
<img width="1919" height="1036" alt="Screenshot 2025-07-19 171634" src="https://github.com/user-attachments/assets/55630d7c-dc8a-404f-add9-bc7b7a8bf45a" />
<img width="1919" height="1031" alt="Screenshot 2025-07-19 171653" src="https://github.com/user-attachments/assets/65a398f9-8be0-40d3-80e3-2efe0bd728fb" />
<img width="1919" height="1028" alt="Screenshot 2025-07-19 171728" src="https://github.com/user-attachments/assets/ebcdba20-e1a3-4c2f-b0a5-e07aeb6da3f5" />




